"..\..\oqtane.framework\oqtane.package\nuget.exe" pack W6HBR.Module.SyncfusionDemo.nuspec 
cp -f "*.nupkg" "..\..\oqtane.framework\Oqtane.Server\Packages\"