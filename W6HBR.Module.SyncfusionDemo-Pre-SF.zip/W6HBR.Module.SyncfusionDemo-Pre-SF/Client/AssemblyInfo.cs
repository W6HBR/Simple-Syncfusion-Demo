using System.Resources;
using Microsoft.Extensions.Localization;

[assembly: RootNamespace("W6HBR.Module.SyncfusionDemo.Client")]
